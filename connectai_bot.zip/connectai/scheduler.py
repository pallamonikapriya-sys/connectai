"""
ConnectAI – Smart Networking Bot
scheduler.py – Daily Match Suggestion Feature

Run this as a separate process (or a cron job / Render cron service).
It sends a daily proactive match suggestion to every registered user.

Usage:
  python scheduler.py

Or add a Render Cron Job:
  Schedule: 0 9 * * *   (every day at 09:00 UTC)
  Command:  python scheduler.py
"""

import os
import time
from dotenv import load_dotenv
from twilio.rest import Client

from database import get_all_users
from matcher import find_matches
from utils import build_match_message

load_dotenv()

ACCOUNT_SID = os.environ.get("TWILIO_ACCOUNT_SID")
AUTH_TOKEN  = os.environ.get("TWILIO_AUTH_TOKEN")
FROM_NUMBER = os.environ.get("TWILIO_WHATSAPP_FROM")   # e.g. "whatsapp:+14155238886"


def send_daily_suggestions():
    """
    Iterate over all users and send each one a fresh top-match suggestion.
    A 1-second delay between messages avoids Twilio rate limits.
    """
    if not all([ACCOUNT_SID, AUTH_TOKEN, FROM_NUMBER]):
        print("[SCHEDULER] Missing Twilio credentials – set env vars and retry.")
        return

    client   = Client(ACCOUNT_SID, AUTH_TOKEN)
    all_users = get_all_users()

    if not all_users:
        print("[SCHEDULER] No registered users found.")
        return

    print(f"[SCHEDULER] Sending daily suggestions to {len(all_users)} users...")

    for user in all_users:
        phone = user.get("phone")
        if not phone:
            continue

        try:
            matches = find_matches(phone, user, top_n=1)
            body    = (
                "🌅 *Good morning from ConnectAI!*\n\n"
                "Here's your *Daily Match Suggestion*:\n\n"
                + build_match_message(matches)
                + "\n\nType *find match* for more suggestions!"
            )

            client.messages.create(
                body=body,
                from_=FROM_NUMBER,
                to=phone,
            )
            print(f"[SCHEDULER] ✅ Sent to {phone}")

        except Exception as e:
            print(f"[SCHEDULER] ❌ Failed for {phone}: {e}")

        time.sleep(1)   # Respect Twilio rate limits

    print("[SCHEDULER] Daily suggestions complete.")


if __name__ == "__main__":
    send_daily_suggestions()
