"""
ConnectAI – Smart Networking Bot
database.py – Firebase Firestore integration

Handles all read/write operations for:
  • user profiles      (collection: "users")
  • conversation state (collection: "sessions")
  • match history      (collection: "match_history")
"""

import os
import datetime
from typing import Optional, dict as Dict, list as List

import firebase_admin
from firebase_admin import credentials, firestore

# ── Initialise Firebase (runs once at import time) ────────────────────────────
_db = None

def _get_db():
    """Lazy-initialise Firestore client."""
    global _db
    if _db is not None:
        return _db

    if not firebase_admin._apps:
        # In production: set GOOGLE_APPLICATION_CREDENTIALS env var to your
        # service-account JSON path, OR use Application Default Credentials on GCP.
        cred_path = os.environ.get("FIREBASE_CREDENTIALS_PATH")
        if cred_path:
            cred = credentials.Certificate(cred_path)
        else:
            # Fallback: Application Default Credentials (works on GCP / Cloud Run)
            cred = credentials.ApplicationDefault()

        firebase_admin.initialize_app(cred)

    _db = firestore.client()
    return _db


# ══════════════════════════════════════════════════════════════════════════════
# USER PROFILE OPERATIONS
# ══════════════════════════════════════════════════════════════════════════════

def get_user(sender: str) -> Optional[Dict]:
    """
    Fetch a user's profile from Firestore.
    Returns the profile dict or None if not found.
    """
    try:
        db  = _get_db()
        doc = db.collection("users").document(_safe_id(sender)).get()
        return doc.to_dict() if doc.exists else None
    except Exception as e:
        print(f"[DB ERROR] get_user({sender}): {e}")
        return None


def save_user(sender: str, profile: Dict) -> bool:
    """
    Create or overwrite a user profile.
    Adds/updates a 'updated_at' timestamp automatically.
    Returns True on success, False on failure.
    """
    try:
        db = _get_db()
        profile["updated_at"] = datetime.datetime.utcnow().isoformat()
        profile["phone"]      = sender          # store sender ID for back-reference
        db.collection("users").document(_safe_id(sender)).set(profile)
        return True
    except Exception as e:
        print(f"[DB ERROR] save_user({sender}): {e}")
        return False


def get_all_users() -> List[Dict]:
    """
    Fetch every registered user profile.
    Used by the matching algorithm.
    """
    try:
        db   = _get_db()
        docs = db.collection("users").stream()
        return [doc.to_dict() for doc in docs]
    except Exception as e:
        print(f"[DB ERROR] get_all_users: {e}")
        return []


# ══════════════════════════════════════════════════════════════════════════════
# SESSION (CONVERSATION STATE) OPERATIONS
# ══════════════════════════════════════════════════════════════════════════════

def get_session(sender: str) -> Optional[Dict]:
    """
    Retrieve the current onboarding/conversation session for a user.
    Returns None if no active session exists.
    """
    try:
        db  = _get_db()
        doc = db.collection("sessions").document(_safe_id(sender)).get()
        return doc.to_dict() if doc.exists else None
    except Exception as e:
        print(f"[DB ERROR] get_session({sender}): {e}")
        return None


def save_session(sender: str, data: Dict) -> bool:
    """
    Save or update the conversation session for a user.
    Merges with existing data so partial updates are safe.
    """
    try:
        db = _get_db()
        db.collection("sessions").document(_safe_id(sender)).set(data, merge=True)
        return True
    except Exception as e:
        print(f"[DB ERROR] save_session({sender}): {e}")
        return False


def clear_session(sender: str) -> bool:
    """
    Delete the session once onboarding is complete or abandoned.
    """
    try:
        db = _get_db()
        db.collection("sessions").document(_safe_id(sender)).delete()
        return True
    except Exception as e:
        print(f"[DB ERROR] clear_session({sender}): {e}")
        return False


# ══════════════════════════════════════════════════════════════════════════════
# MATCH HISTORY OPERATIONS
# ══════════════════════════════════════════════════════════════════════════════

def get_past_matches(sender: str) -> List[str]:
    """
    Return list of phone IDs this user has already been matched with.
    Prevents the same person being suggested repeatedly.
    """
    try:
        db  = _get_db()
        doc = db.collection("match_history").document(_safe_id(sender)).get()
        if doc.exists:
            return doc.to_dict().get("matched_with", [])
        return []
    except Exception as e:
        print(f"[DB ERROR] get_past_matches({sender}): {e}")
        return []


def record_matches(sender: str, matched_phones: List[str]) -> bool:
    """
    Append newly matched phone IDs to the history so they won't repeat.
    """
    try:
        db      = _get_db()
        ref     = db.collection("match_history").document(_safe_id(sender))
        doc     = ref.get()
        existing = doc.to_dict().get("matched_with", []) if doc.exists else []
        updated  = list(set(existing + matched_phones))
        ref.set({"matched_with": updated}, merge=True)
        return True
    except Exception as e:
        print(f"[DB ERROR] record_matches({sender}): {e}")
        return False


# ── Helpers ───────────────────────────────────────────────────────────────────

def _safe_id(sender: str) -> str:
    """
    Firestore document IDs cannot contain '/' or certain special chars.
    Convert 'whatsapp:+919XXXXXXXXX' → 'whatsapp__91XXXXXXXXX'
    """
    return sender.replace(":", "__").replace("+", "").replace(" ", "_")
