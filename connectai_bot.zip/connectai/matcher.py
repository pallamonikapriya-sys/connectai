"""
ConnectAI – Smart Networking Bot
matcher.py – Advanced Matching Algorithm

Scoring rubric
──────────────
  +2  for each common skill
  +1  for each common interest
  +2  for each complementary skill (you have what they lack & vice-versa)

Returns top-3 matches, excluding:
  • the requesting user themselves
  • anyone they've already been matched with
"""

from typing import Dict, List, Tuple
from database import get_all_users, get_past_matches, record_matches


# ── Complementary skill pairs ──────────────────────────────────────────────────
# If user A has skill X and user B has skill Y (or vice-versa) → +2 bonus
COMPLEMENTARY_PAIRS = [
    {"frontend", "backend"},
    {"design", "development"},
    {"ml", "data engineering"},
    {"machine learning", "data engineering"},
    {"ai", "product management"},
    {"marketing", "engineering"},
    {"business", "technical"},
    {"sales", "engineering"},
    {"ux", "backend"},
    {"ui", "backend"},
    {"mobile", "backend"},
    {"devops", "development"},
    {"blockchain", "frontend"},
    {"security", "development"},
    {"research", "engineering"},
]


# ══════════════════════════════════════════════════════════════════════════════
# MAIN MATCH FUNCTION
# ══════════════════════════════════════════════════════════════════════════════

def find_matches(sender: str, user_profile: Dict, top_n: int = 3) -> List[Dict]:
    """
    Find the top-N best-matching users for `sender`.

    Parameters
    ----------
    sender       : The requesting user's phone ID
    user_profile : The requesting user's profile dict
    top_n        : How many results to return (default 3)

    Returns
    -------
    List of dicts, each containing the matched user's profile + their score.
    """
    all_users   = get_all_users()
    past_matches = get_past_matches(sender)

    scored: List[Tuple[int, Dict]] = []

    for candidate in all_users:
        c_phone = candidate.get("phone", "")

        # Skip self
        if c_phone == sender:
            continue

        # Skip already-matched users
        if c_phone in past_matches:
            continue

        score = _compute_score(user_profile, candidate)
        if score > 0:
            scored.append((score, candidate))

    # Sort descending by score
    scored.sort(key=lambda x: x[0], reverse=True)
    top = scored[:top_n]

    # Persist match history so they won't repeat
    matched_phones = [c["phone"] for _, c in top]
    if matched_phones:
        record_matches(sender, matched_phones)

    # Return list of profile dicts enriched with score
    return [{"score": s, **c} for s, c in top]


# ══════════════════════════════════════════════════════════════════════════════
# HACKATHON TEAM FINDER
# ══════════════════════════════════════════════════════════════════════════════

def find_hackathon_team(sender: str, user_profile: Dict, team_size: int = 4) -> List[Dict]:
    """
    Build a balanced hackathon team around the requesting user.
    Strategy: maximise skill diversity across the team while keeping
              interest overlap high.

    Returns up to `team_size - 1` teammates (the requester is slot #1).
    """
    all_users = get_all_users()
    candidates = [u for u in all_users if u.get("phone", "") != sender]

    if not candidates:
        return []

    # Score each candidate as a potential teammate
    scored: List[Tuple[int, Dict]] = []
    for candidate in candidates:
        score = _compute_hackathon_score(user_profile, candidate, scored)
        scored.append((score, candidate))

    scored.sort(key=lambda x: x[0], reverse=True)
    top = scored[: team_size - 1]
    return [{"score": s, **c} for s, c in top]


# ══════════════════════════════════════════════════════════════════════════════
# SCORING HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def _normalise_list(raw) -> List[str]:
    """
    Safely convert a profile field (str or list) to a lowercase list.
    """
    if isinstance(raw, list):
        return [item.lower().strip() for item in raw]
    if isinstance(raw, str):
        return [s.lower().strip() for s in raw.split(",") if s.strip()]
    return []


def _compute_score(user: Dict, candidate: Dict) -> int:
    """
    Core scoring function used for regular matching.
    """
    u_skills    = set(_normalise_list(user.get("skills", [])))
    u_interests = set(_normalise_list(user.get("interests", [])))
    c_skills    = set(_normalise_list(candidate.get("skills", [])))
    c_interests = set(_normalise_list(candidate.get("interests", [])))

    score = 0

    # +2 per common skill
    common_skills = u_skills & c_skills
    score += len(common_skills) * 2

    # +1 per common interest
    common_interests = u_interests & c_interests
    score += len(common_interests) * 1

    # +2 per complementary skill pair
    for pair in COMPLEMENTARY_PAIRS:
        pair_list = list(pair)
        has_a = any(p in u_skills for p in pair_list)
        has_b = any(p in c_skills for p in pair_list)
        # Complementary = one side has it, the other doesn't (but has the other)
        if has_a and has_b:
            # Check they genuinely bring different sides
            u_side = [p for p in pair_list if p in u_skills]
            c_side = [p for p in pair_list if p in c_skills]
            if set(u_side) != set(c_side):
                score += 2

    return score


def _compute_hackathon_score(user: Dict, candidate: Dict, already_selected: List) -> int:
    """
    Hackathon scoring rewards skill diversity across the team.
    Bonus points if the candidate brings skills nobody in the team has yet.
    """
    base = _compute_score(user, candidate)

    # Aggregate skills of already-selected teammates
    team_skills: set = set(_normalise_list(user.get("skills", [])))
    for _, member in already_selected:
        team_skills |= set(_normalise_list(member.get("skills", [])))

    c_skills = set(_normalise_list(candidate.get("skills", [])))
    new_skills = c_skills - team_skills  # Skills this person uniquely adds

    # +3 bonus per truly new skill → encourages diversity
    base += len(new_skills) * 3

    return base
