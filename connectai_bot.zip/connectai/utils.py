"""
ConnectAI – Smart Networking Bot
utils.py – Utility functions

Contains:
  • handle_onboarding()  – step-by-step conversation state machine
  • build_*()            – WhatsApp message formatters
  • ai_fallback_response()
  • normalize()          – text normalisation helper
"""

import random
from typing import Dict, List, Optional

from database import get_user, save_user, save_session, clear_session


# ══════════════════════════════════════════════════════════════════════════════
# ONBOARDING STATE MACHINE
# ══════════════════════════════════════════════════════════════════════════════

def handle_onboarding(sender: str, text: str, session: Dict) -> str:
    """
    Step-by-step onboarding conversation handler.

    Steps:
      1 → Ask name
      2 → Ask skills
      3 → Ask interests
      4 → Ask experience level  → save profile → done
    """
    step = session.get("step", 1)
    data = session.get("data", {})
    mode = session.get("mode", "register")  # "register" or "update"

    # ── Guard against blank input ─────────────────────────────────────────
    if not text.strip():
        return "⚠️ Please send a non-empty reply to continue."

    # ── Step 1: Collect name ──────────────────────────────────────────────
    if step == 1:
        data["name"] = text.strip().title()
        save_session(sender, {"step": 2, "data": data, "mode": mode})
        return (
            f"👋 Nice to meet you, *{data['name']}*!\n\n"
            "💡 *Step 2/4* – What are your *skills*?\n"
            "_(Separate multiple skills with commas)\n"
            "e.g.  Python, React, Machine Learning_"
        )

    # ── Step 2: Collect skills ────────────────────────────────────────────
    if step == 2:
        skills = [s.strip() for s in text.split(",") if s.strip()]
        if not skills:
            return "⚠️ Please enter at least one skill, e.g.  *Python, Design*"
        data["skills"] = skills
        save_session(sender, {"step": 3, "data": data, "mode": mode})
        skills_display = " • ".join(skills)
        return (
            f"✅ Got it! Skills saved: _{skills_display}_\n\n"
            "🌟 *Step 3/4* – What are your *interests*?\n"
            "_(Separate with commas)\n"
            "e.g.  Hackathons, Startups, AI, Open Source, Jobs_"
        )

    # ── Step 3: Collect interests ─────────────────────────────────────────
    if step == 3:
        interests = [i.strip() for i in text.split(",") if i.strip()]
        if not interests:
            return "⚠️ Please enter at least one interest, e.g.  *Startups, Jobs*"
        data["interests"] = interests
        save_session(sender, {"step": 4, "data": data, "mode": mode})
        return (
            "🎯 *Step 4/4* – What's your *experience level*?\n\n"
            "Reply with one of:\n"
            "  1️⃣  *Beginner*\n"
            "  2️⃣  *Intermediate*\n"
            "  3️⃣  *Advanced*"
        )

    # ── Step 4: Collect experience & save ─────────────────────────────────
    if step == 4:
        level_map = {
            "1": "Beginner",  "beginner": "Beginner",
            "2": "Intermediate", "intermediate": "Intermediate",
            "3": "Advanced",  "advanced": "Advanced",
        }
        level = level_map.get(normalize(text))
        if not level:
            return (
                "⚠️ Please reply with *Beginner*, *Intermediate*, or *Advanced* "
                "(or 1, 2, 3)."
            )

        data["experience"] = level

        # Persist the profile to Firestore
        ok = save_user(sender, data)
        clear_session(sender)  # Done with onboarding

        if not ok:
            return (
                "⚠️ There was a problem saving your profile. "
                "Please try again by typing *register*."
            )

        action = "updated" if mode == "update" else "created"
        return (
            f"🎉 *Profile {action} successfully!*\n\n"
            f"👤 Name: *{data['name']}*\n"
            f"🛠 Skills: _{', '.join(data['skills'])}_\n"
            f"🌟 Interests: _{', '.join(data['interests'])}_\n"
            f"📊 Level: *{data['experience']}*\n\n"
            "What would you like to do next?\n"
            "• Type *find match* to discover connections\n"
            "• Type *find hackathon team* to build a team\n"
            "• Type *profile* to review your details"
        )

    # Shouldn't reach here, but just in case
    clear_session(sender)
    return "Something went wrong. Please type *register* to start again."


# ══════════════════════════════════════════════════════════════════════════════
# MESSAGE BUILDERS
# ══════════════════════════════════════════════════════════════════════════════

def build_welcome_message() -> str:
    return (
        "👋 *Welcome to ConnectAI – Smart Networking Bot!* 🤖\n\n"
        "I help professionals and students connect with the right people.\n\n"
        "━━━━━━━━━━━━━━━━━\n"
        "📋 *Available Commands*\n"
        "━━━━━━━━━━━━━━━━━\n"
        "• *register*           → Create your profile\n"
        "• *profile*            → View your profile\n"
        "• *find match*         → Discover top matches\n"
        "• *update profile*     → Edit your details\n"
        "• *find hackathon team*→ Build a hackathon team\n"
        "━━━━━━━━━━━━━━━━━\n\n"
        "🚀 Type *register* to get started!"
    )


def build_profile_message(user: Dict) -> str:
    skills    = _fmt_list(user.get("skills", []))
    interests = _fmt_list(user.get("interests", []))
    exp       = user.get("experience", "N/A")
    name      = user.get("name", "N/A")
    updated   = user.get("updated_at", "")[:10] if user.get("updated_at") else "N/A"

    return (
        "👤 *Your ConnectAI Profile*\n"
        "━━━━━━━━━━━━━━━━━\n"
        f"🏷  *Name:*        {name}\n"
        f"🛠  *Skills:*      {skills}\n"
        f"🌟 *Interests:*   {interests}\n"
        f"📊 *Level:*       {exp}\n"
        f"📅 *Updated:*     {updated}\n"
        "━━━━━━━━━━━━━━━━━\n\n"
        "• Type *find match* to discover connections\n"
        "• Type *update profile* to edit details"
    )


def build_match_message(matches: List[Dict]) -> str:
    if not matches:
        return (
            "😕 *No new matches found right now.*\n\n"
            "This could mean:\n"
            "• You've already been matched with everyone!\n"
            "• Not enough users are registered yet.\n\n"
            "Check back soon as more people join. 🌱"
        )

    lines = ["🎯 *Your Top Matches on ConnectAI*\n", "━━━━━━━━━━━━━━━━━"]
    for i, match in enumerate(matches, 1):
        name      = match.get("name", "Unknown")
        skills    = _fmt_list(match.get("skills", []))
        interests = _fmt_list(match.get("interests", []))
        exp       = match.get("experience", "N/A")
        score     = match.get("score", 0)

        lines.append(
            f"\n{_rank_emoji(i)} *Match #{i} — {name}*\n"
            f"   🛠 Skills:    {skills}\n"
            f"   🌟 Interests: {interests}\n"
            f"   📊 Level:     {exp}\n"
            f"   💯 Score:     {score} pts"
        )
        lines.append("   ─────────────────")

    lines.append(
        "\n💡 _Scores are based on shared skills, interests & complementary expertise._\n"
        "Type *find match* again to see new suggestions later!"
    )
    return "\n".join(lines)


def build_hackathon_team_message(team: List[Dict]) -> str:
    if not team:
        return (
            "😕 *Couldn't build a hackathon team right now.*\n\n"
            "Not enough registered users yet. Share ConnectAI with your network! 🚀"
        )

    lines = [
        "🏆 *Your Hackathon Dream Team!*\n",
        "━━━━━━━━━━━━━━━━━",
        "_Here are the best teammates for your next hackathon:_\n",
    ]
    for i, member in enumerate(team, 1):
        name      = member.get("name", "Unknown")
        skills    = _fmt_list(member.get("skills", []))
        interests = _fmt_list(member.get("interests", []))
        exp       = member.get("experience", "N/A")

        lines.append(
            f"👤 *Teammate #{i} — {name}*\n"
            f"   🛠 Skills:    {skills}\n"
            f"   🌟 Interests: {interests}\n"
            f"   📊 Level:     {exp}\n"
            f"   ─────────────────"
        )

    lines.append(
        "\n🎉 _Your team is built for skill diversity and shared passion._\n"
        "Go build something amazing! 🚀"
    )
    return "\n".join(lines)


# ══════════════════════════════════════════════════════════════════════════════
# AI FALLBACK
# ══════════════════════════════════════════════════════════════════════════════

# Pool of friendly fallback responses so it doesn't feel robotic
_FALLBACK_POOL = [
    (
        "🤔 I didn't quite catch that!\n\n"
        "Here's what I can help you with:\n"
        "• *register* – Create a profile\n"
        "• *find match* – Meet new people\n"
        "• *profile* – View your profile\n"
        "• *find hackathon team* – Build a team\n"
        "• *update profile* – Edit your details"
    ),
    (
        "💬 Hmm, I'm not sure what you mean by that.\n\n"
        "Try one of these commands:\n"
        "• *register*\n"
        "• *find match*\n"
        "• *profile*\n"
        "• *update profile*\n"
        "• *find hackathon team*"
    ),
    (
        "🤖 I'm ConnectAI – I'm great at networking but still learning new phrases!\n\n"
        "Type *hi* to see all available commands."
    ),
]


def ai_fallback_response(text: str) -> str:
    """Return a random friendly fallback response for unrecognised input."""
    return random.choice(_FALLBACK_POOL)


# ══════════════════════════════════════════════════════════════════════════════
# HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def normalize(text: str) -> str:
    """Lowercase, strip, collapse whitespace."""
    return " ".join(text.lower().strip().split())


def _fmt_list(items) -> str:
    """Format a list (or comma-string) into a readable string."""
    if isinstance(items, list):
        return ", ".join(items) if items else "N/A"
    return items or "N/A"


def _rank_emoji(rank: int) -> str:
    return {1: "🥇", 2: "🥈", 3: "🥉"}.get(rank, "🏅")
