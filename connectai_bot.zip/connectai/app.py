"""
ConnectAI – Smart Networking Bot
app.py – Main Flask application entry point

Handles incoming Twilio WhatsApp webhooks and routes messages
to the appropriate conversation handlers.
"""

import os
from flask import Flask, request
from twilio.twiml.messaging_response import MessagingResponse
from dotenv import load_dotenv

from database import get_user, save_session, get_session, clear_session
from matcher import find_matches, find_hackathon_team
from utils import (
    handle_onboarding,
    build_welcome_message,
    build_profile_message,
    build_match_message,
    build_hackathon_team_message,
    ai_fallback_response,
    normalize,
)

# ── Load environment variables from .env ──────────────────────────────────────
load_dotenv()

app = Flask(__name__)

# ── Twilio webhook endpoint ────────────────────────────────────────────────────
@app.route("/webhook", methods=["POST"])
def webhook():
    """
    Receives every WhatsApp message sent to your Twilio number.
    Reads the sender's phone number and their message, then
    decides what action to take.
    """
    incoming_msg = request.form.get("Body", "").strip()
    sender       = request.form.get("From", "")   # e.g. "whatsapp:+919XXXXXXXXX"

    resp = MessagingResponse()
    msg  = resp.message()

    try:
        reply = route_message(sender, incoming_msg)
    except Exception as e:
        # Safety net – never let the webhook crash silently
        print(f"[ERROR] route_message failed for {sender}: {e}")
        reply = (
            "⚠️ Something went wrong on our end. Please try again in a moment.\n"
            "If the issue persists, type *hi* to restart."
        )

    msg.body(reply)
    return str(resp)


# ── Message router ────────────────────────────────────────────────────────────
def route_message(sender: str, text: str) -> str:
    """
    Central routing function.
    1. If the user is mid-onboarding  → continue the flow
    2. Else check for known commands  → execute command
    3. Else return AI fallback        → friendly unknown-input reply
    """
    cmd = normalize(text)

    # ── Check for active onboarding session first ──────────────────────────
    session = get_session(sender)
    if session and session.get("step"):
        return handle_onboarding(sender, text, session)

    # ── Known top-level commands ───────────────────────────────────────────
    if cmd in ("hi", "hello", "hey", "start"):
        return build_welcome_message()

    if cmd == "register":
        # Start onboarding – save step=1 in session
        save_session(sender, {"step": 1})
        return (
            "🎉 *Welcome to ConnectAI Networking Bot!*\n\n"
            "Let's build your profile in a few easy steps.\n\n"
            "👤 *Step 1/4* – What's your *full name*?"
        )

    if cmd == "profile":
        user = get_user(sender)
        if not user:
            return (
                "😕 You don't have a profile yet!\n"
                "Type *register* to create one."
            )
        return build_profile_message(user)

    if cmd in ("find match", "findmatch", "match"):
        user = get_user(sender)
        if not user:
            return "❌ Please *register* first before finding matches."
        matches = find_matches(sender, user)
        return build_match_message(matches)

    if cmd in ("update profile", "updateprofile", "update"):
        user = get_user(sender)
        if not user:
            return "❌ You don't have a profile yet. Type *register* to create one."
        # Re-use onboarding flow; mark as update
        save_session(sender, {"step": 1, "mode": "update"})
        return (
            "✏️ *Update Profile*\n\n"
            "Let's refresh your details!\n\n"
            "👤 *Step 1/4* – What's your *full name*? (or send current name to keep it)"
        )

    if cmd in ("find hackathon team", "hackathon", "hackathon team"):
        user = get_user(sender)
        if not user:
            return "❌ Please *register* first before finding a hackathon team."
        team = find_hackathon_team(sender, user)
        return build_hackathon_team_message(team)

    if cmd in ("help", "menu", "commands"):
        return build_welcome_message()

    # ── Unknown input → AI-style fallback ─────────────────────────────────
    return ai_fallback_response(text)


# ── Run locally ────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=False)
