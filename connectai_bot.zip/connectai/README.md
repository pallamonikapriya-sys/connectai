# 🤖 ConnectAI – Smart WhatsApp Networking Bot

> A production-ready WhatsApp bot that helps professionals and students discover meaningful connections based on skills, interests, and experience.

---

## ✨ Features

| Feature | Description |
|---|---|
| 🧠 Intelligent Onboarding | 4-step guided profile creation via WhatsApp |
| 🔥 Firebase Firestore | Cloud database for profiles & sessions |
| 🎯 Smart Matching | Weighted algorithm: common skills (+2), interests (+1), complementary skills (+2) |
| 🏆 Hackathon Teams | Group matching optimised for skill diversity |
| 📅 Daily Suggestions | Proactive daily match via scheduler |
| 🛡 Error Handling | Graceful handling of empty input, DB failures, unknown commands |
| 🚀 Render Ready | Procfile + PORT handling for one-click deploy |

---

## 📁 Project Structure

```
connectai/
├── app.py              ← Flask app + Twilio webhook router
├── database.py         ← Firebase Firestore CRUD operations
├── matcher.py          ← Matching & hackathon team algorithm
├── utils.py            ← Onboarding flow + message builders
├── scheduler.py        ← Daily match suggestion (run as cron)
├── requirements.txt    ← Python dependencies
├── Procfile            ← Render/Heroku deployment command
├── .env.example        ← Environment variable template
├── .gitignore
└── README.md
```

---

## 🛠 Local Setup

### Prerequisites
- Python 3.10+
- A [Twilio account](https://www.twilio.com) (free sandbox works)
- A [Firebase project](https://console.firebase.google.com) with Firestore enabled
- [ngrok](https://ngrok.com) (to expose localhost to Twilio)

---

### Step 1 – Clone & install

```bash
git clone https://github.com/your-username/connectai.git
cd connectai

python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

---

### Step 2 – Firebase setup

1. Go to [Firebase Console](https://console.firebase.google.com) → Create project
2. Enable **Firestore Database** (Start in test mode for development)
3. Go to **Project Settings → Service Accounts → Generate new private key**
4. Download the JSON file and save it as `serviceAccountKey.json` in the project root
5. In `.env`, set: `FIREBASE_CREDENTIALS_PATH=serviceAccountKey.json`

---

### Step 3 – Twilio WhatsApp setup

1. Sign up at [twilio.com](https://www.twilio.com)
2. Go to **Messaging → Try it Out → Send a WhatsApp message**
3. Note your **Account SID**, **Auth Token**, and sandbox number (e.g. `+14155238886`)
4. To connect your phone: send the join code (e.g. `join pretty-morning`) to the Twilio sandbox number on WhatsApp

---

### Step 4 – Configure environment

```bash
cp .env.example .env
```

Edit `.env` with your real credentials:

```env
TWILIO_ACCOUNT_SID=ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
TWILIO_AUTH_TOKEN=your_auth_token
TWILIO_WHATSAPP_FROM=whatsapp:+14155238886
FIREBASE_CREDENTIALS_PATH=serviceAccountKey.json
```

---

### Step 5 – Run locally

```bash
python app.py
```

The server starts at `http://localhost:5000`

---

### Step 6 – Expose with ngrok

```bash
ngrok http 5000
```

Copy the HTTPS URL (e.g. `https://abc123.ngrok.io`)

---

### Step 7 – Configure Twilio webhook

1. Go to Twilio Console → **Messaging → Settings → WhatsApp Sandbox Settings**
2. Set **"When a message comes in"** to:
   ```
   https://abc123.ngrok.io/webhook
   ```
3. Make sure the method is **HTTP POST**
4. Save

---

### Step 8 – Test it!

Open WhatsApp and message your Twilio sandbox number:

```
hi
register
profile
find match
find hackathon team
update profile
```

---

## 🚀 Deploy on Render

### Step 1 – Push to GitHub

```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/your-username/connectai.git
git push -u origin main
```

> ⚠️ Make sure `.gitignore` is in place before pushing. Never commit `.env` or `serviceAccountKey.json`.

---

### Step 2 – Create Render Web Service

1. Go to [render.com](https://render.com) → **New → Web Service**
2. Connect your GitHub repo
3. Configure:
   - **Environment:** Python
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `gunicorn app:app --bind 0.0.0.0:$PORT`
   - **Plan:** Free

---

### Step 3 – Add environment variables on Render

In Render dashboard → **Environment** tab, add:

| Key | Value |
|---|---|
| `TWILIO_ACCOUNT_SID` | Your Twilio SID |
| `TWILIO_AUTH_TOKEN` | Your Twilio token |
| `TWILIO_WHATSAPP_FROM` | `whatsapp:+14155238886` |
| `FIREBASE_CREDENTIALS_PATH` | `/etc/secrets/serviceAccountKey.json` |

---

### Step 4 – Upload Firebase key as Secret File

1. Render dashboard → **Environment → Secret Files**
2. Filename: `serviceAccountKey.json`
3. Contents: paste your Firebase JSON key
4. Render stores it at `/etc/secrets/serviceAccountKey.json`

---

### Step 5 – Update Twilio webhook

1. Get your Render URL (e.g. `https://connectai.onrender.com`)
2. Update Twilio webhook to:
   ```
   https://connectai.onrender.com/webhook
   ```

---

### Step 6 – Daily Suggestions (Optional Cron Job)

1. Render dashboard → **New → Cron Job**
2. Connect the same repo
3. **Schedule:** `0 9 * * *` (9 AM UTC daily)
4. **Command:** `python scheduler.py`
5. Add the same environment variables

---

## 💬 Available Commands

| Command | Action |
|---|---|
| `hi` | Show welcome message & commands |
| `register` | Start 4-step onboarding |
| `profile` | View your saved profile |
| `find match` | Get top 3 best matches |
| `update profile` | Edit your profile |
| `find hackathon team` | Get a diverse hackathon team |

---

## 🧮 Matching Algorithm

```
Score = (common skills × 2) + (common interests × 1) + (complementary skills × 2)
```

**Complementary pairs include:**
- Frontend ↔ Backend
- Design ↔ Development  
- ML ↔ Data Engineering
- AI ↔ Product Management
- UX ↔ Backend
- ... and more (see `matcher.py`)

**Hackathon teams** get an extra **+3 per unique skill** a candidate brings that nobody else on the team has yet — maximising diversity.

---

## 🔒 Security Notes

- Never commit `.env` or your Firebase key to git
- Use Render Secret Files for sensitive credentials in production
- Rotate Twilio Auth Tokens periodically
- Enable Firestore security rules before going public

---

## 📜 License

MIT – use freely, build something great! 🚀
